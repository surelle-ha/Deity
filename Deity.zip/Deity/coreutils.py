from os import system
from os import walk
import os
from termcolor import colored
from etc.mslep.mslep import mslep
from dmagi import *
import itertools
import threading
import configparser
import time
import sys
import getpass
import socket
import platform

global_password = "root"
#configuration parser   
config = configparser.ConfigParser()
config.read('usr/config.ini')
user = config['su']['user']
passwd = config['su']['passwd']
#decrypt
passwd = mslep('-d', passwd, global_password)

def load():
    done = False
    def animate():
        for c in itertools.cycle(['/', '-', '\\', '|']):
            if done:
                break
            sys.stdout.write('\rloading ' + c)
            sys.stdout.flush()
            time.sleep(0.1)
    
    t = threading.Thread(target=animate)
    t.start()
    time.sleep(2)
    done = True

def sysrecall():
    print(f"Machine:   {platform.machine()}")
    print(f"Platform:  {platform.platform()}")
    print(f"System:    {platform.system()}")
    print(f"Processor: {platform.processor()}")

class bcolors:
    HEADER = '\033[95m'
    OKBLUE = '\033[94m'
    OKCYAN = '\033[96m'
    OKGREEN = '\033[92m'
    WARNING = '\033[93m'
    FAIL = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'

def modifyuser(item, value):# unfinish
    if item == "password" or item == "username":
        config.read('usr/config.ini')
        config.set('su', item, value)
        with open('usr/config.ini', 'w') as configfile:
            config.write(configfile)
        restart()
    else:
        print("HELPPP! USERNAME OR PASSWORD")

def dmagi(type, pkg):    
    if type == "install":
        install(pkg)
    elif type == "remove":
        print("")
    elif type == "update":
        print("")
    elif type == "show":
        print(show.help)
    else:
        raise TypeError()

def is_connected():
    try:
        socket.create_connection(("1.1.1.1", 53))
        print(colored('CONNECTED TO A NETWORK', 'grey', 'on_green'))
        return True
    except OSError:
        print(colored('NO INTERNET CONNECTION', 'white', 'on_red'))
        return False

def login():
    while True:
        try:
            print(coretext.header)
            pswd = getpass.getpass(bcolors.FAIL+"█"+bcolors.ENDC+" Password: ")
            pswdlen = len(pswd)
            if pswd == passwd:
                print('')
                break
            else:
                clear()
                print(colored('INVALID PASSWORD: '+pswd[0]+("*"*(pswdlen-1)), 'white', 'on_red'))
                continue
        except IndexError:
            clear()
            print(colored('INVALID PASSWORD: NO INPUT', 'white', 'on_red'))
                     
glob_dir = os.getcwd()                                        
def display(*text):
    print(bcolors.BOLD+(" ".join(text))+bcolors.ENDC)

def gdisplay(*text):
    print(bcolors.OKGREEN+(" ".join(text))+bcolors.ENDC)

def rdisplay(*text):
    print(bcolors.FAIL+(" ".join(text))+bcolors.ENDC)
    
def bdisplay(*text):
    print(bcolors.OKBLUE+(" ".join(text))+bcolors.ENDC)
    
def ydisplay(*text):
    print(bcolors.WARNING+(" ".join(text))+bcolors.ENDC)
    
def ls(dire=os.getcwd()):
    system("ls "+dire)
    
def cd(*dire):
    system("cd "+"".join(dire))

def clear(): 
    system('clear') 

def restart():
    clear()
    system("python deity.py")

def dexit():
    exit()

def showf(dir = "./"):
    etc = []
    for (dirpath, dirnames, filenames) in walk(dir):
        etc.extend(filenames)
        break
    for x in range(len(etc)):
        print(bcolors.OKCYAN+etc[x]+bcolors.ENDC), 
        
class coretext():
    header = bcolors.BOLD+bcolors.OKBLUE+"""
██████████████████████████████████████████████
█ Install a package: dmagi install <package> █
█ More  information: dmagi info <package>    █
█ Search    package: dmagi search <package>  █
█ Update    package: dmagi update <package>  █
██████████████████████████████████████████████"""+bcolors.ENDC+"""
 
 """+bcolors.FAIL+"""█"""+bcolors.ENDC+""" Title: Deity Framework      """+bcolors.OKGREEN+"""█"""+bcolors.ENDC+""" Version: 1.2
 
 """+bcolors.WARNING+"""█"""+bcolors.ENDC+""" Developer: Harold Eustaquio """+bcolors.OKCYAN+"""█"""+bcolors.ENDC+""" Year: 2020
 
 """+bcolors.OKBLUE+"""█"""+bcolors.ENDC+""" Website: """+bcolors.UNDERLINE+"""http://deity-dmagi.tk"""+bcolors.ENDC+"""
 
 """+bcolors.HEADER+"""█"""+bcolors.ENDC+""" Note: This project is under development.
         You may experience loopholes and
         bugs. Please report any issues you
         might experience with Deity
         Framework
"""