# Developer: Harold Eustaquio(PHI)
# Language-Based: Python 3
# Framework: Deity
# Year: 2020
# Original Core Utility[DE]
# -----------------------------------------
#    __________________________________
#   |Note:                             |
#   |                                  |
#   |                                  |
#   |                                  |
#   |                                  |
#    ==================================
#
import configparser
from os import system, name, path 
from os import walk
from coreutils import *
from dmagi import *
import sys
from etc.mslep.mslep import mslep

global_password = "root"
                 
#configuration parser   
config = configparser.ConfigParser()
config.read('usr/config.ini')
user = config['su']['user']
passwd = config['su']['passwd']
name = config['main']['name']
version = config['main']['version']
developer = config['main']['developer']
welvoice = config['system']['welcome_voice']
syslock = config['system']['syslock']

#decrypt
user = mslep('-d', user, global_password)
passwd = mslep('-d', passwd, global_password)

#header
clear()
if syslock == "1":
    login()
clear()
is_connected()
print(coretext.header)
if welvoice == '0':
    print("")    
elif welvoice == '1':
    system("play -q audio/welcome-m.mp3")
elif welvoice == '2':
    system("play -q audio/welcome-f.mp3") 
#test array of packages
func_dict = {'dmagi':dmagi,'clear':clear,'dexit':dexit,'restart':restart,'showf':showf,'ls':ls,'cd':cd,'display':display,'gdisplay':gdisplay,'rdisplay':rdisplay,'bdisplay':bdisplay,'ydisplay':ydisplay, 'modifyuser':modifyuser,'sysrecall':sysrecall}

while True:
    try:
        #PS1
        cmd = input(bcolors.OKGREEN+'['+bcolors.ENDC+f'{user}'+bcolors.OKGREEN+'@'+bcolors.ENDC+f'{name}'+bcolors.OKGREEN+']'+bcolors.ENDC+'$ ').split()
        func_dict[cmd[0]](*cmd[1:])
       
        if cmd[0] == "":
            continue
        elif cmd[0] == "exit":
            print(bcolors.WARNING+bcolors.BOLD+"[code:72] Exit.\n"+bcolors.ENDC)
            break
        else:
            print("")  
    except KeyError:
        etc = []
        for (dirpath, dirnames, filenames) in walk("etc/"):
            etc.extend(filenames)
            break
        if cmd[0]+".py" in etc:
            system('python3 etc/'+cmd[0]+'.py')
        elif path.exists("etc/"+cmd[0]+"/"+cmd[0]+".py"):# file.py
            system('python3 etc/'+cmd[0]+'/'+cmd[0]+'.py '+' '.join(cmd[1:]))
        
        elif path.exists("etc/"+cmd[0]+"/"+cmd[0]+".c"):# file.c
            system('gcc etc/'+cmd[0]+'/'+cmd[0]+'.c '+' '.join(cmd[1:]))
        
        elif path.exists("etc/"+cmd[0]+"/"+cmd[0]+".cpp"):# file.cpp
            system('gcc etc/'+cmd[0]+'/'+cmd[0]+'.cpp '+' '.join(cmd[1:]))
               
        elif path.exists("etc/"+cmd[0]+"/"+cmd[0]+".sh"):# file.sh
            system('bash etc/'+cmd[0]+'/'+cmd[0]+'.sh '+' '.join(cmd[1:]))
        
        
            
        
                  
        else:
            print(bcolors.FAIL+bcolors.BOLD+"[code:90] Command ["+cmd[0]+"] Not Found.\n"+bcolors.ENDC)
            
    except TypeError:
        print(bcolors.WARNING+bcolors.BOLD+"[code:56] Invalid Syntax or Parameter for ["+cmd[0]+"].\n"+bcolors.ENDC)
    except IndexError:
        print("")
    except KeyboardInterrupt:
        print("Logout..")
        exit(1)