#dmagi tool manager--
#Developed by Harold Eustaquio
import urllib.request
import configparser
from os import system, name, walk
import sys
import requests

class bcolors:
    HEADER = '\033[95m'
    OKBLUE = '\033[94m'
    OKCYAN = '\033[96m'
    OKGREEN = '\033[92m'
    WARNING = '\033[93m'
    FAIL = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'

#configuration parser   
config = configparser.ConfigParser()
config.read('usr/config.ini')
www = config['server']['www']
dwww = config['server']['dwww']
repo = config['server']['repo']

def repoexists(path):
    r = requests.head(path)
    return r.status_code == requests.codes.ok

#dmagi install <pkg>
def install(pkg):
    try:
        print(bcolors.BOLD+bcolors.OKGREEN)
        print("Checking Internet Connection [Connection]")
        ncheck = urllib.request.urlopen("https://www.google.com",timeout=10)
        print("Connected to the Internet [Connection.result]")
        print("Checking Server Availability = "+www+" [DP31]")
        up = urllib.request.urlopen(www).getcode()
        if up == 200:
            print(bcolors.OKGREEN+"Server is online [DP31.result] "+bcolors.ENDC)
        else:
            print(bcolors.FAIL+"Unable to connect on the server [DP31.result]"+bcolors.ENDC)
            print(bcolors.WARNING+"Installation Terminated [DP31.result]"+bcolors.ENDC)    
        print(bcolors.BOLD+bcolors.OKGREEN+"Checking Download Server Availability = "+dwww+"/"+repo+" [DP32]")
        up = urllib.request.urlopen(dwww).getcode()
        if up == 200:
            print(bcolors.OKGREEN+" Download Server is online [DP32.result] "+bcolors.ENDC)
        else:
            print(bcolors.FAIL+"Unable to connect on the server [DP32.result]"+bcolors.ENDC)
            print(bcolors.WARNING+"Installation Terminated [DP32.result]"+bcolors.ENDC)
        print(bcolors.BOLD+bcolors.OKGREEN+"Finding ["+pkg+"] in d1repo repository [DP33]"+bcolors.ENDC)
        repock = repoexists('http://deity-dmagi.tk/d1repo/'+pkg+'.zip')
        if repock == True:
            print(bcolors.BOLD+bcolors.OKGREEN+"["+pkg+"] found on d1repo repository [DP33.result]"+bcolors.ENDC)
            system("cd etc && curl -O http://deity-dmagi.tk/d1repo/"+pkg+".zip && unzip "+pkg+".zip && rm -rf "+pkg+".zip")
            
        else:
            print(bcolors.BOLD+bcolors.FAIL+"["+pkg+"] does not exist in any repository [DP33.result]"+bcolors.ENDC)
        print(bcolors.ENDC)
    except urllib.error.URLError as e: 
    	print(bcolors.FAIL+"No internet connection [Connection.result]"+bcolors.ENDC)





#dmagi update <pkg>










#dmagi remove <pkg>








#dmagi show help
class show():
    help = bcolors.WARNING+"""
============================================
dmagi - deity original package manager.
usage: 
    
    dmagi <action> <package>
    action:
        install = download and install tools.        
        update = replace the the current package with latest version.
        remove = delete package.
===========================================
    """+bcolors.ENDC
    
    
if __name__ == "__main__":
    try:
        process = str(sys.argv[1])
        pkg = str(sys.argv[2])
        if process == "install":
            install(pkg)
    except IndexError:
        print(show.help)


    