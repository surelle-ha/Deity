/*         
 *
 *
 *
 *
 *
 */

//LIBRARY//
#include <stdio.h> 
#include <assert.h>
#include <ctype.h>
#include <string.h>
#include <stdlib.h>
#include <setjmp.h>
#include <unistd.h>
#include <errno.h>
#include <netdb.h>
#include <time.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

//DEFAULT FILE LIBRARY//
#include "lib/dc_game.c"
#include "lib/dc_math.c"
//#include "lib/dc_network.c"
#include "lib/dc_util.c"
#include "lib/dc_numsystem.c"
#include "lib/minIni/minIni.c"
#include "lib/dc_pkgmanager.c"
#include "lib/dc_cryptography.c"

//INSTALLED FILED LIBRARY//


//DEFINE LIBRARY//
#define TRY do{ jmp_buf ex_buf__; if( !setjmp(ex_buf__) ){
#define CATCH } else {
#define ETRY } }while(0)
#define THROW longjmp(ex_buf__, 1) 

/*[UPDATES]
 *1.ABOUT PAGE
 */

/*[NOTE]
 *Some functions are not working on Windows Operating System
 *This console was developed in Linux Environment
 */
  char dev[100]="DevilCloud[c2020]\nDeveloped by Harold\n";
  const char ini[] = "settings.ini";
int main(){
  char test[200]="Ak8e# MqaJ7 AjKtH Tp47i zLv6i AjKtH Ak8e# Ak8e# MqaJ7 AjKtH Ak8e# Ak8e# Ak8e# AjKtH Ak8e# zMQ@i AjKtH Ak8e# AjKtH AjKtH";
dcdecrypt(test);
int pkgs = pkgchecker();
int files = filechecker();
if(files==0){//file verification start//
TRY{
  char passini[100], devstatus[100], baseos[100], proglang[100], dev[100];
    long l = ini_gets("information", "CONSOLE_STATUS", "dummy", devstatus, sizearray(devstatus), ini);
    long x = ini_gets("information", "CONSOLE_BASEOS", "dummy", baseos, sizearray(baseos), ini);
    long c = ini_gets("information", "CONSOLE_LANGUAGE", "dummy", proglang, sizearray(proglang), ini);
    long b = ini_gets("information", "CONSOLE_DEVELOPER", "dummy", dev, sizearray(dev), ini);
    long n = ini_gets("admin", "ADM_PASSWORD", "dummy", passini, sizearray(passini), ini);
  clean();
  banner();
  pkgconnect("madman");
  printf("\nWelcome to DevilCloud Commandline!");//NOT AVAILABLE//
  printf("\n  Dev  Status: %s", devstatus);
  printf("\n    OS  Based: %s", baseos);
  printf("\n    Prog Lang: %s", proglang);
  printf("\n    Developer: %s", dev);
  printf("\nPkg Installed: %d", pkgs);
  printf("\n");
  
  printf("\nLogin to  Console: -kth [Password]");
  printf("\nInstall a package: -kth S package");//NOT AVAILABLE//
  printf("\nMore  information: -kth [D|F|Q|R|S|T|U]h");//NOT AVAILABLE//
  printf("\nSearch   packages: -kth Ss query");//NOT AVAILABLE//
  printf("\nUpgrade  packages: -kth Syu");//NOT AVAILABLE//
  
printf("\n\nChat:  https://discord.gg/wyvuR9X79W");
printf("\nForum: http://forestfiend.cf");
printf("\nHelp: info query and man query\n\n");


    
    
    //long u = ini_puts("first", "alt", "hello", ini); 
    
  do{
    execution();
  char key[100],pass[100];
  scanf("%s", &key);
  if(strcmp(key, "-kth")==0){
        printf("Password: ");
        scanf("%s", &pass);
        if(strcmp(pass, passini)==0){
        printf("PERMISSION GRANTED\n\n");
        console(); //MAIN>>>CONSOLE FUNCTION//
        }else{
          printf("PERMISSION DENIED!\n\n");
        }
  }else{
    printf("PERMISSION DENIED!\n\n");
  }
  
  }while(1);
  
}CATCH{
  printf("Something Went Wrong!\n");
} 
ETRY;
}else{
  banner();
  printf("\nSYSTEM: WARNING MISSING FILE(404)");
}//file verification end//
}

//System Function//
  
int console(){//Console Function//
      clean();
    char version[100];
    long n = ini_gets("information", "CONSOLE_VERSION", "dummy", version, sizearray(version), ini);
      printf("\n\nDevil Cloud [%s]\n", version);
      printf("<c>DevilCloud. All rights reserved. 2020\n");
      char con_init, con_key[100], con_attri1[100], con_priv='u';
     for(int conloop=0;conloop<1;conloop--){
       execution();
       scanf("%1s%s %[^\n]", &con_init,&con_key, &con_attri1);
       getchar();
       if(con_init=='-'){
         
         if(strcmp(con_key,"admin")==0){
           if(strcmp(con_attri1,"0")==0){
             long u = ini_puts("admin", "ADM_STATUS", "inactive", ini);
           }else if(strcmp(con_attri1, "1")==0){
             long u = ini_puts("admin", "ADM_STATUS", "active", ini);
           }
         }else if(strcmp(con_key,"decbi")==0){//DIVIDE NUMBERS//
           int pol = atoi(con_attri1);
           decbi(pol);
           printf("\n");
         }else if(strcmp(con_key,"pkginstall")==0){//DIVIDE NUMBERS//
           pkgsearch(con_attri1);
           printf("\n\n");
         }else if(strcmp(con_key,"pkgconnect")==0){//DIVIDE NUMBERS//
           pkgconnect(con_attri1);
           printf("\n\n");
         }else if(strcmp(con_key,"timer")==0){//DIVIDE NUMBERS//
           timer(atoi(con_attri1));
         }else if(strcmp(con_key,"encrypt")==0){//DIVIDE NUMBERS//
           dcencrypt(con_attri1, 273);
           printf("\n");
         }else if(strcmp(con_key,"bidec")==0){//DIVIDE NUMBERS//
           bidec(con_attri1);
           printf("\n");
         }else if(strcmp(con_key,"qu")==0){//DIVIDE NUMBERS//
           if(strcmp(con_attri1, "0")==0){
           int con_quo_total, con_quo_input;
           printf("[+]>>>");
           scanf("%d",&con_quo_total);
           do{
            printf("[%d]>>>", con_quo_total);
            if(scanf("%d", &con_quo_input)){
              con_quo_total = qu(con_quo_total, con_quo_input); 
            }else{
              break;
            }             
           }while(1>0);
           }else{
             printf(" Invalid '%s' Attribute[-command [attribute]]. \nUse '-help 0' to show commands. \n", con_attri1);
           }
         }else if(strcmp(con_key,"ml")==0){//MULTIPLY NUMBERS//
           if(strcmp(con_attri1, "0")==0){
           int con_prod_total, con_prod_input;
           printf("[+]>>>");
           scanf("%d",&con_prod_total);
           do{
            printf("[%d]>>>", con_prod_total);
            if(scanf("%d", &con_prod_input)){
              con_prod_total = ml(con_prod_total, con_prod_input); 
            }else{
              break;
            }             
           }while(1>0);
           }else{
             printf(" Invalid '%s' Attribute[-command [attribute]]. \nUse '-help 0' to show commands. \n", con_attri1);
           }
         }else if(strcmp(con_key,"sb")==0){//SUBTRACT NUMBERS//
           if(strcmp(con_attri1, "0")==0){
           int con_diff_total, con_diff_input;
           printf("[+]>>>");
           scanf("%d",&con_diff_total);
           do{
            printf("[%d]>>>", con_diff_total);
            if(scanf("%d", &con_diff_input)){
              con_diff_total = sb(con_diff_total, con_diff_input); 
            }else{
              break;
            }             
           }while(1>0);    
           }else{
             printf(" Invalid '%s' Attribute[-command [attribute]]. \nUse '-help 0' to show commands. \n", con_attri1);
           }                  
         }else if(strcmp(con_key,"sm")==0){//SUM NUMBERS//
           if(strcmp(con_attri1, "0")==0){
           int con_sum_total=0, con_sum_input;
           do{
           printf("[%d]>>>", con_sum_total);
           if(scanf("%d", &con_sum_input)){
             con_sum_total = sm(con_sum_total, con_sum_input);
           }else{
             break;
           } 
           }while(1>0);
           }else{
             printf(" Invalid '%s' Attribute[-command [attribute]]. \nUse '-help 0' to show commands. \n", con_attri1);
           }
         }else if(strcmp(con_key,"help")==0){//SHOW HELP OPTIONS//
           if(strcmp(con_attri1, "0")==0){
            help();
           }else{
            printf(" Invalid '%s' Attribute[-command [attribute]]. \nUse '-help 0' to show commands. \n", con_attri1);
           }
         }else if(strcmp(con_key,"clean")==0){//SHOW HELP OPTIONS//
           if(strcmp(con_attri1, "0")==0){
            clean();
           }else{
            printf(" Invalid '%s' Attribute[-command [attribute]]. \nUse '-help 0' to show commands. \n", con_attri1);
           }
         }else if(strcmp(con_key,"system")==0){//SHOW HELP OPTIONS//
           if(strcmp(con_attri1, "-cpu")==0){
            cpu();
           }else{
            printf(" Invalid '%s' Attribute[-command [attribute]]. \nUse '-help 0' to show commands. \n", con_attri1);
           }
         }else if(strcmp(con_key,"dcfetch")==0){//SHOW HELP OPTIONS//
           if(strcmp(con_attri1, "0")==0){ 
             nfetch();
            }else{
            printf(" Invalid '%s' Attribute[-command [attribute]]. \nUse '-help 0' to show commands. \n", con_attri1);
            }
         }else if(strcmp(con_key,"exit")==0){//EXIT CONSOLE//
           if(strcmp(con_attri1, "0")==0){
            break;
           }else{
            printf(" Invalid '%s' Attribute[-command [attribute]]. \nUse '-help 0' to show commands. \n", con_attri1);
           } 
         }else if(strcmp(con_key,"game_rps")==0){
           if(strcmp(con_attri1, "-e")==0){
             gamerpseasy();
           }else if(strcmp(con_attri1, "-h")==0){
            gamerpshard();
           }else{
            printf(" Invalid '%s' Attribute[-command [attribute]]. \nUse '-help 0' to show commands. \n", con_attri1);
           } 
         }else if(strcmp(con_key,"game_hl")==0){
           if(strcmp(con_attri1, "-e")==0){
             gamehleasy();
           }else if(strcmp(con_attri1, "-m")==0){
            gamehlmedium();
           }else if(strcmp(con_attri1, "-h")==0){
            gamehlhard();
           }else if(strcmp(con_attri1, "-x")==0){
            gamehlextreme();
           }else{
            printf(" Invalid '%s' Attribute[-command [attribute]]. \nUse '-help 0' to show commands. \n", con_attri1);
           } 
         }else if(strcmp(con_key,"netip")==0){
           if(strcmp(con_attri1, "0")==0){
            //netip();
           }else{
            printf(" Invalid '%s' Attribute[-command [attribute]]. \nUse '-help 0' to show commands. \n", con_attri1);
           } 
         }else if(strcmp(con_key,"report")==0){
           if(strcmp(con_attri1, "ip_")==0){
             //netip();
           }else if(strcmp(con_attri1, "dev_")==0){
            printf("%s", dev);
           }else if(strcmp(con_attri1, "cpu_")==0){
             cpu();
           }else if(strcmp(con_attri1, "banner_")==0){
             banner();
           }else if(strcmp(con_attri1, "dir_")==0){
             printf("Current Directory: ");
             getdir(); 
             printf("\n"); 
           }else{
            printf("%s\n", con_attri1);
           } 
         }else{
           printf(" Unknown '%s' Command[-command [attribute]]. \nUse '-help 0' to show commands. \n", con_key);
         }
       }else{
         printf(" Invalid Command Format[-command [attribute]]. \nUse '-help 0' to show commands. \n");
       }
   } 
 return 0;
}

execution(){
  char admstat[100];
  long l = ini_gets("admin", "ADM_STATUS", "dummy", admstat, sizearray(admstat), ini);
  
  time_t rawtime; 
    struct tm* timeinfo;  
    char buffer[80]; 
    time(&rawtime); 
    timeinfo = localtime(&rawtime); 
    if(strcmp(admstat, "inactive")==0){
    strftime(buffer, 80, 
             "[root@u%I:%M%p~]$", 
             timeinfo); 
    puts(buffer);
    
    }else{
    strftime(buffer, 80, 
             "[root@a%I:%M%p~]$", 
             timeinfo); 
    puts(buffer);
    }
    
    
}

//CONSOLE OPERATIONS //
int help(){ //FUNCTION HELP CONSOLE//
  printf("\nHELP=======================================");
  printf("\nUSAGE: -[Command] [Attribute]");
  printf("\n=======================================HELP");
  printf("\n  PURPOSE  |  COMMAND  |  ATTRIBUTE  | ");
  printf("\n===========================================");
  printf("\n  Network  |   netip   |      0      | show host name & host ip");
  printf("\n  Network  |           |      0      | ");
  printf("\n  Network  |           |      0      | ");
  printf("\n  Utility  |  report   |   [string]  | ");
  printf("\n  Utility  |  fcreate  |      0      | ");
  printf("\n  Utility  |  fdelete  |      0      | ");
  printf("\n   Math    |    sm     |      0      | Addition");
  printf("\n   Math    |    sb     |      0      | Subtraction");
  printf("\n   Math    |    ml     |      0      | Multiplication");
  printf("\n   Math    |    qu     |      0      | Division"); 
  printf("\n   Game    |  game_rps |     -e      | ");
  printf("\n   Game    |  game_rps |     -h      | ");
  printf("\n   Game    |  game_hl  |     -e      | ");
  printf("\n   Game    |  game_hl  |     -m      | ");
  printf("\n   Game    |  game_hl  |     -h      | ");
  printf("\n   Game    |  game_hl  |     -x      | ");
  printf("\n  System   |   system  |    -cpu     | ");
  printf("\n           |           |             | ");
}

int cpu(int argc, char **argv)
{
   FILE *cpuinfo = fopen("/proc/cpuinfo", "rb");
   char *arg = 0;
   size_t size = 0;
   while(getdelim(&arg, &size, 0, cpuinfo) != -1)
   {
      puts(arg);
   }
   free(arg);
   fclose(cpuinfo);
   return 0;
}