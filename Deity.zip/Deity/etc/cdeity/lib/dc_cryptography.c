//LIBRARY//
#include <stdio.h> 
#include <assert.h>
#include <ctype.h>
#include <string.h>
#include <stdlib.h>
#include <setjmp.h>
#include <unistd.h>
#include <errno.h>
#include <netdb.h>
#include <time.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

void unicryption(int nume){
  int num,temp,factor=1;
  num=nume;
  temp=num;
  while(temp){
      temp=temp/10;
      factor = factor*10;
  }
  while(factor>1){
      factor = factor/10;
      int uni = num/factor;
      char unx[50];
      sprintf(unx, "%d", uni);   
     
      if(strcmp(unx, "0")==0){
        printf("$");
      }else if(strcmp(unx, "1")==0){
        printf("Ak8e# ");
      }else if(strcmp(unx, "2")==0){
        printf("kPq7* ");
      }else if(strcmp(unx, "3")==0){
        printf("kLpP0 ");
      }else if(strcmp(unx, "4")==0){
        printf("MqaJ7 ");
      }else if(strcmp(unx, "5")==0){
        printf("MbB0& ");
      }else if(strcmp(unx, "6")==0){
        printf("GoP1@ ");
      }else if(strcmp(unx, "7")==0){
        printf("zLv6i ");
      }else if(strcmp(unx, "8")==0){
        printf("zMQ@i ");
      }else if(strcmp(unx, "9")==0){
        printf("Tp47i ");
      }
  
      num = num % factor;
  }
  
}

void dcencrypt(char stng[], int key){
  
  int n = strlen(stng);
  for(int enloop=0;enloop<=n;enloop++){
  char strr = stng[enloop];
  
  int num,temp,factor=1;
  num= 0 + strr;
  temp=num;
  while(temp){
      temp=temp/10;
      factor = factor*10;
  }
  while(factor>1){
      
      factor = factor/10;
      int po = 0;
      int initi[20];
      initi[po]=num/factor;
      unicryption(initi[po]);
      po++;
      num = num % factor;
  }
  printf("AjKtH ");
  } 
}

void dcdecrypt(char script[1000]){
  char ascii[100];
  char * token = strtok(script, " ");
  while(token!=NULL){
    if(strcmp(token, "AjKtH")==0){
      printf(" ");
    }else if(strcmp(token, "Ak8e#")==0){
      printf("1");
    }else if(strcmp(token, "kPq7*")==0){
      printf("2"); 
    }else if(strcmp(token, "kLpP0")==0){
      printf("3"); 
    }else if(strcmp(token, "MqaJ7")==0){
      printf("4"); 
    }else if(strcmp(token, "MbB0&")==0){
      printf("5");
    }else if(strcmp(token, "GoP1@")==0){
      printf("6");
    }else if(strcmp(token, "zLv6i")==0){
      printf("7"); 
    }else if(strcmp(token, "zMQ@i")==0){
      printf("8"); 
    }else if(strcmp(token, "Tp47i")==0){
      printf("9"); 
    }else{
      printf("PLEASE ENTER VALID INPUT.");
    }
    
    token = strtok(NULL, " ");
  }
}