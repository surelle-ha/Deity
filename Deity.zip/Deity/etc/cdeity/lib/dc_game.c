//LIBRARY//
#include <stdio.h> 
#include <ctype.h>
#include <string.h>
#include <stdlib.h>
#include <setjmp.h>
#include <unistd.h>
#include <errno.h>
#include <netdb.h>
#include <time.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#define TRY do{ jmp_buf ex_buf__; if( !setjmp(ex_buf__) ){
#define CATCH } else {
#define ETRY } }while(0)
#define THROW longjmp(ex_buf__, 1) 


//CONSOLE GAME//
  
int gamerpseasy(){//ROCK PAPER SCISSOR EASY//
  char retry;
  do{
          char usergamerpsplayer;
          printf("\n[R=Rock][P=Paper][S=Scissor]>>>");
          scanf("%s", &usergamerpsplayer);
          int usergamerpsaieasy = (rand()%(1-70+1))+1;
           if(usergamerpsplayer=='r' ||usergamerpsplayer=='R' ||usergamerpsplayer=='p' ||usergamerpsplayer=='P' ||usergamerpsplayer=='s' ||usergamerpsplayer=='S'){
             if(usergamerpsaieasy<=75&&usergamerpsaieasy>=51){
               char aieasyc= 'R', aieasys= 'r' ;
               if(aieasyc==usergamerpsplayer||aieasys==usergamerpsplayer){
                 printf("\nPlayer=Rock\nAI=Rock\nResult: Draw! ");
               }else{
                 if(usergamerpsplayer=='P' || usergamerpsplayer=='p'){
                   printf("\nPlayer=Paper\nAI=Rock\nResult: Win! ");
                 }else if(usergamerpsplayer=='S' || usergamerpsplayer=='s'){
                   printf("\nPlayer=Scissor\nAI=Rock\nResult: Lost! ");
                 }
               }
             }else if(usergamerpsaieasy<=50&&usergamerpsaieasy>=26){
               char aieasyc= 'P', aieasys= 'p'; 
               if(aieasyc==usergamerpsplayer||aieasys==usergamerpsplayer){
                 printf("\nPlayer=Paper\nAI=Paper\nResult: Draw! ");
               }else{
                 if(usergamerpsplayer=='R' || usergamerpsplayer=='r'){
                   printf("\nPlayer=Rock\nAI=Paper\nResult: Lost! ");
                 }else if(usergamerpsplayer=='S' || usergamerpsplayer=='s'){
                   printf("\nPlayer=Scissor\nAI=Paper\nResult: Win! ");
                 }
               }
             }else if(usergamerpsaieasy<=25&&usergamerpsaieasy>=0){
               char aieasyc= 'S', aieasys= 's';
               if(aieasyc==usergamerpsplayer||aieasys==usergamerpsplayer){
                 printf("\nPlayer=Scissor\nAI=Scissor\nResult: Draw! ");
               }else{
                 if(usergamerpsplayer=='P' || usergamerpsplayer=='p'){
                   printf("\nPlayer=Paper\nAI=Scissor\nResult: Lost! ");
                 }else if(usergamerpsplayer=='R' || usergamerpsplayer=='r'){
                   printf("\nPlayer=Rock\nAI=Scissor\nResult: Win! ");
                 }
               }
             }
           }else{
             printf("Sys| Invalid User Input... \n\n");
           }
            printf("\nWOULD YOU LIKE TO PLAY AGAIN?\n[Y]Yes/[X]Exit:");
            scanf("%s", &retry);
             }while(retry=='y'); 
}

int gamerpshard(){ //ROCK PAPER SCISSOR HARD//
  char retry;
  do{
                char usergamerpsplayer;
            printf("\n[R=Rock][P=Paper][S=Scissor]>>>");
              scanf("%s", &usergamerpsplayer);
              if(usergamerpsplayer=='R' || usergamerpsplayer=='r'){
                printf("\nPlayer=Rock\nAI=Paper\nResult: Lost! ");
              }else if(usergamerpsplayer=='P' || usergamerpsplayer=='p'){
                printf("\nPlayer=Paper\nAI=Scissor\nResult: Lost! ");
              }else if(usergamerpsplayer=='S' || usergamerpsplayer=='s'){
                printf("\nPlayer=Scissor\nAI=Rock\nResult: Lost! ");
              }else{
                printf("Sys| Invalid User Input... \n\n");
              }
               printf("\nWOULD YOU LIKE TO PLAY AGAIN?\n[Y]Yes/[X]Exit:");
               scanf("%s", &retry);
             }while(retry=='y');  
}

int gamehleasy(){ //HIGHERLOWER EASY//
  char retry;
  do{
            char usergamehlplayer;
            int usergamehlplayerinput, usergamehlplayerscore=100;
            printf("\n\nD E V I L C L O U D\n");
              printf("Sys| Welcome to DC HigherLower BitGame! \n");
              printf("Difficulty: Easy[MAX:100]\nPlayer:[S=Start][E=Exit]:");
              scanf("%s", &usergamehlplayer);
              if(usergamehlplayer=='S' || usergamehlplayer=='s'){
                int usergamehlrandom = (rand()%(1-100+1))+1;
                 for(int inf=0;inf<1;inf--){
                   printf("\nPlayer:[Input a number][]:");
                   scanf("%d", &usergamehlplayerinput);
                   if(usergamehlplayerinput==usergamehlrandom){//HL-True//
                     printf("\nBitGame:[WIN!]\nScore:[%d]",usergamehlplayerscore);
                     break;
                   }else if(usergamehlplayerinput<usergamehlrandom){
                     printf("\nBitGame:[HIGHER!]");
                     usergamehlplayerscore-=1;
                   }else if(usergamehlplayerinput>usergamehlrandom){
                     printf("\nBitGame:[LOWER!]"); 
                     usergamehlplayerscore-=1;
                   }else{
                     printf("\nBitGame:[INVALID NUMBER!]"); 
                     usergamehlplayerscore-=1;
                   }
                 }
              }else if(usergamehlplayer=='E' || usergamehlplayer=='e'){
                break;
              }
           printf("\nWOULD YOU LIKE TO PLAY AGAIN?\n[Y]Yes/[X]Exit:");
             scanf("%s", &retry);
          }while(retry=='y'); 
}

int gamehlmedium(){ //HIGHERLOWER MEDIUM//
  char retry;
  do{
            char usergamehlplayer;
            int usergamehlplayerinput, usergamehlplayerscore=100;
            printf("\n\nD E V I L C L O U D\n");
              printf("Sys| Welcome to DC HigherLower BitGame! \n");
              printf("Difficulty: Medium[MAX:500]\nPlayer:[S=Start][E=Exit]:");
              scanf("%s", &usergamehlplayer);
              if(usergamehlplayer=='S' || usergamehlplayer=='s'){
                int usergamehlrandom = (rand()%(1-500+1))+1;
                 for(int inf=0;inf<1;inf--){
                   printf("\nPlayer:[Input a number][]:");
                   scanf("%d", &usergamehlplayerinput);
                   if(usergamehlplayerinput==usergamehlrandom){//HL-True//
                     printf("\nBitGame:[WIN!]\nScore:[%d]",usergamehlplayerscore);
                     break;
                   }else if(usergamehlplayerinput<usergamehlrandom){
                     printf("\nBitGame:[HIGHER!]");
                     usergamehlplayerscore-=3;
                   }else if(usergamehlplayerinput>usergamehlrandom){
                     printf("\nBitGame:[LOWER!]"); 
                     usergamehlplayerscore-=3;
                   }else{
                     printf("\nBitGame:[INVALID NUMBER!]"); 
                     usergamehlplayerscore-=3;
                   }
                 }
              }else if(usergamehlplayer=='E' || usergamehlplayer=='e'){
                break;
              }
           printf("\nWOULD YOU LIKE TO PLAY AGAIN?\n[Y]Yes/[X]Exit:");
             scanf("%s", &retry);
          }while(retry=='y'); 
}

int gamehlhard(){ //HIGHERLOWER HARD//
  char retry;
  do{
            char usergamehlplayer;
            int usergamehlplayerinput, usergamehlplayerscore=100;
            printf("\n\nD E V I L C L O U D\n");
              printf("Sys| Welcome to DC HigherLower BitGame! \n");
              printf("Difficulty: Hard[MAX:1000]\nPlayer:[S=Start][E=Exit]:");
              scanf("%s", &usergamehlplayer);
              if(usergamehlplayer=='S' || usergamehlplayer=='s'){
                int usergamehlrandom = (rand()%(1-1000+1))+1;
                 for(int inf=0;inf<1;inf--){
                   printf("\nPlayer:[Input a number][]:");
                   scanf("%d", &usergamehlplayerinput);
                   if(usergamehlplayerinput==usergamehlrandom){//HL-True//
                     printf("\nBitGame:[WIN!]\nScore:[%d]",usergamehlplayerscore);
                     break;
                   }else if(usergamehlplayerinput<usergamehlrandom){
                     printf("\nBitGame:[HIGHER!]");
                     usergamehlplayerscore-=5;
                   }else if(usergamehlplayerinput>usergamehlrandom){
                     printf("\nBitGame:[LOWER!]"); 
                     usergamehlplayerscore-=5;
                   }else{
                     printf("\nBitGame:[INVALID NUMBER!]"); 
                     usergamehlplayerscore-=5;
                   }
                 }
              }else if(usergamehlplayer=='E' || usergamehlplayer=='e'){
                break;
              }
           printf("\nWOULD YOU LIKE TO PLAY AGAIN?\n[Y]Yes/[X]Exit:");
             scanf("%s", &retry);
          }while(retry=='y'); 
}

int gamehlextreme(){ //HIGHERLOWER EXTREME//
  char retry;
  do{
            char usergamehlplayer;
            int usergamehlplayerinput, usergamehlplayerscore=100;
            printf("\n\nD E V I L C L O U D\n");
              printf("Sys| Welcome to DC HigherLower BitGame! \n");
              printf("Difficulty: Extreme[MAX:10000]\nPlayer:[S=Start][E=Exit]:");
              scanf("%s", &usergamehlplayer);
              if(usergamehlplayer=='S' || usergamehlplayer=='s'){
                int usergamehlrandom = (rand()%(1-10000+1))+1;
                 for(int inf=0;inf<1;inf--){
                   printf("\nPlayer:[Input a number][]:");
                   scanf("%d", &usergamehlplayerinput);
                   if(usergamehlplayerinput==usergamehlrandom){//HL-True//
                     printf("\nBitGame:[WIN!]\nScore:[%d]",usergamehlplayerscore);
                     break;
                   }else if(usergamehlplayerinput<usergamehlrandom){
                     printf("\nBitGame:[HIGHER!]");
                     usergamehlplayerscore-=10;
                   }else if(usergamehlplayerinput>usergamehlrandom){
                     printf("\nBitGame:[LOWER!]"); 
                     usergamehlplayerscore-=10;
                   }else{
                     printf("\nBitGame:[INVALID NUMBER!]"); 
                     usergamehlplayerscore-=10;
                   }
                 }
              }else if(usergamehlplayer=='E' || usergamehlplayer=='e'){
                break;
              }
           printf("\nWOULD YOU LIKE TO PLAY AGAIN?\n[Y]Yes/[X]Exit:");
             scanf("%s", &retry);
          }while(retry=='y'); 
}