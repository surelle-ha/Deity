//LIBRARY//
#include <stdio.h> 
#include <ctype.h>
#include <string.h>
#include <stdlib.h>
#include <setjmp.h>
#include <unistd.h>
#include <errno.h>
#include <netdb.h>
#include <time.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>


int sm(int x, int y){ //FUNCTION SUM CONSOLE//
  return x+y;
}

int sb(int x, int y){ //FUNCTION DIFFERENCE CONSOLE//
  return x-y;
}

int ml(int x, int y){ //FUNCTION PRODUCT CONSOLE//
  return x*y;
}

int qu(int x, int y){ //FUNCTION QUOTIENT CONSOLE//
  return x/y;
}