//LIBRARY//
#include <stdio.h> 
#include <assert.h>
#include <ctype.h>
#include <string.h>
#include <stdlib.h>
#include <setjmp.h>
#include <unistd.h>
#include <errno.h>
#include <netdb.h>
#include <time.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>


//COMPUTER NUMBER SYSTEM//

 
int decbi(int nb){
  int num,temp,factor=1;
  num=nb;
  temp=num;
  while(temp){
      temp=temp/10;
      factor = factor*10;
  }
  while(factor>1){
      factor = factor/10;
      if(num/factor==0){
        printf("0000 ");
      }else if(num/factor==1){
        printf("0001 ");
      }else if(num/factor==2){
        printf("0010 ");
      }else if(num/factor==3){
        printf("0011 ");
      }else if(num/factor==4){
        printf("0100 ");
      }else if(num/factor==5){
        printf("0101 ");
      }else if(num/factor==6){
        printf("0110 ");
      }else if(num/factor==7){
        printf("0111 ");
      }else if(num/factor==8){
        printf("1000 ");
      }else if(num/factor==9){
        printf("1001 ");
      }else{
        printf("???? ");
      }
      
      num = num % factor;
  }
  
  return 0;
}

void bidec(char binary[1000]){
  
  char * token = strtok(binary, " ");
  while(token!=NULL){
    if(strcmp(token, "0000")==0){
      printf("0");
    }else if(strcmp(token, "0001")==0){
      printf("1");
    }else if(strcmp(token, "0010")==0){
      printf("2");
    }else if(strcmp(token, "0011")==0){
      printf("3");
    }else if(strcmp(token, "0100")==0){
      printf("4");
    }else if(strcmp(token, "0101")==0){
      printf("5");
    }else if(strcmp(token, "0110")==0){
      printf("6");
    }else if(strcmp(token, "0111")==0){
      printf("7");
    }else if(strcmp(token, "1000")==0){
      printf("8");
    }else if(strcmp(token, "1001")==0){
      printf("9");
    }else{
      printf("?"); 
    }
    
    token = strtok(NULL, " ");
  }
}