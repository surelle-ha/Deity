   int pkgchecker(){
    int pkgchecked=0;
    char pkgs[][50]={"lib/minIni/minIni.c",
                 "lib/dc_util.c", 
                 "lib/dc_math.c",
                 "lib/dc_numsystem.c", 
                 "lib/dc_pkgmanager.c", 
                 "lib/dc_game.c",
                 "lib/dc_network.c", 
                 "lib/dc_cryptography.c"
                 };
    size_t n = sizeof(pkgs)/sizeof(pkgs[0]);
    for(int pkgloop = 0;pkgloop < n;pkgloop++){
    FILE *file;
      if((file = fopen(pkgs[pkgloop],"r"))!=NULL){
         pkgchecked+=1;
         fclose(file);
       }
     }
    return pkgchecked;
   }
   
   int pkgsearch(char search[50]){
    char pkgs[][50]={"atomic",
                 "yasha", 
                 "madman",
                 "thors", 
                 "devilman", 
                 "darkcloud",
                 "mantha", 
                 "deadcore"
                 };
    int error=0;
    size_t n = sizeof(pkgs)/sizeof(pkgs[0]);
    for(int pkgloop = 0;pkgloop < n;pkgloop++){
       
       if(strcmp(pkgs[pkgloop], search)==0){
         printf("package <%s> found! ", search);
         printf("\ninstall %s? [y/n]: ", search);
         char insch;
         scanf("%s", &insch);
         if(insch=='Y'||insch=='y'){
           printf("INSTALLED");
           //INSTALLATION PROCESS HERE//
           break;
         }else{
           break;
         }
         
       }
       
       if(error==n-1){
         printf("file not exist");
       }
       error++;
     }
    return 0;
   }
  

int filechecker(){
    int filechecked=0;
    char files[][50]={"settings.ini"
                 };
    size_t n = sizeof(files)/sizeof(files[0]);
    for(int pkgloop = 0;pkgloop < n;pkgloop++){
    FILE *file;
      if((file = fopen(files[pkgloop],"r"))!=NULL){
         
         fclose(file);
       }else{
         filechecked-=1;
       }
     }
    return filechecked;
   } 
  
  int pkgconnect(char pkg[100]){
    pkgconnectloader(pkg);
    return 0;
  }
 
 int pkgconnectloader(char pkgname[100]){
   printf("\n+ checking package... +");
   
   char pkgs[][50]={"atomic",
                 "yasha", 
                 "madman",
                 "thors", 
                 "devilman", 
                 "darkcloud",
                 "mantha", 
                 "deadcore"
                 };
    int error=0;
    size_t n = sizeof(pkgs)/sizeof(pkgs[0]);
    for(int pkgloop = 0;pkgloop < n;pkgloop++){
       
       if(strcmp(pkgs[pkgloop], pkgname)==0){
         sleep(2);
         printf("\n+ processing package %s... +", pkgname);
         sleep(3); 
         printf("\n+ package %s processed... +", pkgname);
         printf("\n\nx connected to %s... x\n", pkgname);
         if(error==0){//atomic//
           
         }else if(error==1){//yasha//
           
         }else if(error==2){//madman//
           
         }else if(error==3){//thors//
           
         }else if(error==4){//devilman//
           
         }else if(error==5){//darkcloud//
           
         }else if(error==6){//mantha//
           
         }else if(error==7){//deadcore//
           
         }else if(error==8){//
           
         }else if(error==9){//
           
         } 
         break;
       }
       
       if(error==n-1){
         sleep(2);
         printf("\n+ cannot find package %s... +", pkgname);
         sleep(1);        
         printf("\n\nx error[404] package %s did not exist... x\n", pkgname);
         break;
       }
       error++;
      } 
   
   
   
   return 0;
 }