//UTILITIES FUNCTION//
  
int timer(int sec){
  while(sec!=-1){
    printf("\n Timer:\t") ;
    printf("%d second(s)" , sec);
    sec-- ;
    sleep(1);
  } 
  printf("\n\n");
}

int clean() {
  #ifdef _WIN32 
      #ifdef _WIN64
          system("cls");
      #else 
          system("cls");
      #endif
  #else
    #ifdef __linux__
          system("clear");
      #else           
      #endif       
  #endif 
  return 0;

}

void getdir(){
  char cwd[AF_MAX]; 
  if (getcwd(cwd, sizeof(cwd)) != NULL) { 
  printf("%s", cwd); 
  } else { 
  perror("getcwd() error");
  } 
}


int banner(){
printf("\n  ____             _ _  ____ _                 _");
printf("\n |  _ \\  _____   _(_) |/ ___| | ___  _   _  __| |");
printf("\n | | | |/ _ \\ \\ / / | | |   | |/ _ \\| | | |/ _` |");
printf("\n | |_| |  __/\\ V /| | | |___| | (_) | |_| | (_| |");
printf("\n |____/ \\___| \\_/ |_|_|\\____|_|\\___/ \\__,_|\\__,_|\n");
printf("\n ================================================\n");                                                 
  
}


int nfetch(){
printf("\n                   -`                    root@localhost ");
printf("\n                  .o+`                   --------------");
printf("\n                 `ooo/                   OS: Arch Linux ARM aarch");
printf("\n                `+oooo:                  Kernel: 4.14.116-generic");
printf("\n               `+oooooo:                 Uptime: 4 days, 1 hour,");
printf("\n               -+oooooo+:                Packages: 153 (pacman)");
printf("\n             `/:-:++oooo+:               Shell: bash 5.0.18");
printf("\n            `/++++/+++++++:              Terminal: proot");
printf("\n           `/++++++++++++++:             CPU: Hisilicon Kirin980");
printf("\n          `/+++ooooooooooooo/`           Memory: 4190MiB / 7598Mi");
printf("\n         ./ooosssso++osssssso+`");
printf("\n        .oossssso-````/ossssss+`");
printf("\n       -osssssso.      :ssssssso.");
printf("\n      :osssssss/        osssso+++.");
printf("\n     /ossssssss/        +ssssooo/-");
printf("\n   `/ossssso+/:-        -:/+osssso+-");
printf("\n  `+sso+:-`                 `.-/+oso:");
printf("\n `++:.                           `-/+/");
printf("\n .`                                 `/");
} 