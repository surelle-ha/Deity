# conmath - continous mathematical operation
# developed by Harold Eustaquio
import sys

class bcolors:
    HEADER = '\033[95m'
    OKBLUE = '\033[94m'
    OKCYAN = '\033[96m'
    OKGREEN = '\033[92m'
    WARNING = '\033[93m'
    FAIL = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'

def add():
    print(bcolors.WARNING+"Press CTRL + C to terminate current operation."+bcolors.ENDC)
    sum = 0
    while True:
        try:
            sum += float(input("["+str(sum)+"]"))
        except KeyboardInterrupt:
            print("") 
            exit()
        except ValueError:
            print(bcolors.WARNING+"[WARNING] Returned a Value Error."+bcolors.ENDC)
         
def sub():
    print(bcolors.WARNING+"Press CTRL + C to terminate current operation."+bcolors.ENDC)
    dif = float(input("Enter initial value: "))
    while True:
        try:
            dif -= float(input("["+str(dif)+"]"))
        except KeyboardInterrupt:
            print("") 
            exit()
        except ValueError:
            print(bcolors.WARNING+"[WARNING] Returned a Value Error."+bcolors.ENDC)
    
def mul():
    print(bcolors.WARNING+"Press CTRL + C to terminate current operation."+bcolors.ENDC)
    prod = float(input("Enter initial value: "))
    while True:
        try:
            prod *= float(input("["+str(prod)+"]"))
        except KeyboardInterrupt:
            print("") 
            exit()
        except ValueError:
            print(bcolors.WARNING+"[WARNING] Returned a Value Error."+bcolors.ENDC)
   
def div():
    print(bcolors.WARNING+"Press CTRL + C to terminate current operation."+bcolors.ENDC)
    qu = float(input("Enter initial value: "))
    while True:
        try:
            qu /= float(input("["+str(qu)+"]"))
        except KeyboardInterrupt:
            print("") 
            exit()
        except ValueError:
            print(bcolors.WARNING+"[WARNING] Returned a Value Error."+bcolors.ENDC)
    
def helpi():
    print("####### ConMath - HELP ######")
    print("Usage: conmath [option]\n")
    print("\tOptions(Operation)")
    print("\t\t-a | Addition")
    print("\t\t-s | Subtraction")
    print("\t\t-m | Multiplication")
    print("\t\t-d | Division")
    print("\t\t-h / -help | Help(this)\n")

if __name__ == "__main__":
    try:
        operation = str(sys.argv[1])
        if operation == "-a":
            add()
        elif operation == "-s":
            sub()
        elif operation == "-m":
            mul()
        elif operation == "-d":
            div()
        elif operation == "-h" or operation == "-help":
            helpi()
    except IndexError:
        helpi()
    