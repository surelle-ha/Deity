from os import system
from termcolor import colored

class info():
    version = "1.2"

print("Welcome to DCMD v"+info.version)
try:
    while True:
        cmd = input(colored('[dcmd]=} ', 'grey', 'on_green'))
        system(cmd)
except KeyboardInterrupt:
    print(colored('CLOSED', 'white', 'on_red')+"\n")