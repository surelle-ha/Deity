#This cryptography is just a a prototype.
#Cryptography: MSLEP Password Multiple Security Layer Encryption for Passwords
import sys
import re
from termcolor import colored
from cryptography.fernet import Fernet

inikey = bytes('JFLPc9BfU5-pXsyMjKBRHDR55S_7aHNsBMkc1OHIP_A=', 'utf-8')

class txtc:
    HEADER = '\033[95m'
    OKBLUE = '\033[94m'
    OKCYAN = '\033[96m'
    OKGREEN = '\033[92m'
    WARNING = '\033[93m'
    FAIL = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'

class ver():
    cver = "1.1"

def hlp():
    print(txtc.OKCYAN+"""
███████████████████████████████████████"""+txtc.ENDC+"""
 Multiple Security Layer Encryption for Pass
 Usage:
     Encryption: mslep -e <text> <password>
     Decryption: mslep -d <l3text> <key>
      Show help: mslep -h
   Show version: mslep -v

"""+txtc.OKCYAN+"""███████████████████████████████████████"""+txtc.ENDC+"""
 
 """+txtc.OKBLUE+"""█"""+txtc.ENDC+""" Version: """+ver.cver+"""
    """)

def l3encrypt(message: bytes, key: bytes) -> bytes:
    return Fernet(key).encrypt(message)

def l3decrypt(token: bytes, key: bytes) -> bytes:
    return Fernet(key).decrypt(token)

def encrypt(text, passi):
    passint = 0
    enc = ["[L1]Encrpted Text: "]
    enc1 = ["[L2]Encrpted Text: "]
    for x in range(len(passi)):
        passint += ord(passi[x])
    for x in range(len(text)):
        value = str(ord(text[x])+passint)+"B"
        enc.append(value)
    print("".join(enc)+" [SLayerOne.success]")
    for x in range(len(enc)-1):
        for y in range(len(enc[x+1])):
            if enc[x+1][y] == '0':
                enc1.append("y3K")
            elif enc[x+1][y] == '1':
                enc1.append("H8P")
            elif enc[x+1][y] == '2':
                enc1.append("Lp0")
            elif enc[x+1][y] == '3':
                enc1.append("3zB")
            elif enc[x+1][y] == '4':
                enc1.append("i3O")
            elif enc[x+1][y] == '5':
                enc1.append("Ax8")
            elif enc[x+1][y] == '6':
                enc1.append("7cQ")
            elif enc[x+1][y] == '7':
                enc1.append("mZ9")
            elif enc[x+1][y] == '8':
                enc1.append("Tm3")
            elif enc[x+1][y] == '9':
                enc1.append("6Gd")
            elif enc[x+1][y] == 'B':
                enc1.append("%")
    print("".join(enc1)+" [SLayerTwo.success]")
    data = str("".join(enc1))
    key = inikey
    return print(txtc.BOLD+txtc.OKGREEN+"[L3]Encrpted Text: "+colored(l3encrypt(bytes(data, 'utf-8'), key).decode("utf-8"),'red', 'on_white')+txtc.OKGREEN+" [SLayerThree.success]"+txtc.ENDC)

def decrypt(enc, passwd):
    l3 = l3decrypt(bytes(enc,'utf-8'), inikey)
    dcl3r = str(l3.decode('utf-8'))
    print(dcl3r)
    dcl3 = dcl3r.split()
    l3 = dcl3[2]
    l3 = l3.split('%')
    dencascii = []
    for x in range(len(l3)-1):
        bitt = re.findall('...', l3[x])
        denc1 = []
        for y in range(len(bitt)):
            if bitt[y] == "y3K":
                denc1.append('0')
            elif bitt[y] == "H8P":
                denc1.append('1')
            elif bitt[y] == "Lp0":
                denc1.append('2')
            elif bitt[y] == "3zB":
                denc1.append('3')
            elif bitt[y] == "i3O":
                denc1.append("4")
            elif bitt[y] == "Ax8":
                denc1.append('5')
            elif bitt[y] == "7cQ":
                denc1.append('6')
            elif bitt[y] == "mZ9":
                denc1.append('7')
            elif bitt[y] == "Tm3":
                denc1.append('8')
            elif bitt[y] == "6Gd":
                denc1.append('9')
            
        dencascii.append("".join(denc1))
    passint = 0
    for x in range(len(passwd)):
        passint += ord(passwd[x])
    for x in range(len(dencascii)):
        dencascii[x] = int(dencascii[x]) - passint
    for x in range(len(dencascii)):
        dencascii[x] = chr(dencascii[x])
    dectext = "".join(dencascii)
    print(txtc.BOLD+txtc.OKGREEN+"[L1]Encrpted Text: "+dectext+txtc.ENDC)
    return dectext
            
def mslep(process, text, passi):
    if process == "-E" or process == "-e":
        aster = len(passi)
        print(txtc.OKGREEN+txtc.BOLD)
        print("Encryption process started [EP30]")
        print("Encrypting text: "+text+" with password: "+("*"*aster)+" [EP31]")
        result = encrypt(text, passi)
        print(txtc.ENDC)
        return result
    elif process == "-D" or process == "-d":
        aster = len(passi)
        print(txtc.OKGREEN+txtc.BOLD)
        print("Decryption process started [DP30]")
        print("Decrypting w/ MSLEP: "+text+" with key: "+("*"*aster)+" [DP31]")
        result = decrypt(text, passi)
        print(txtc.ENDC)
        return result
    return 0
if __name__ == "__main__":
    try:
        process = str(sys.argv[1])
        text = str(sys.argv[2])
        passi = str(sys.argv[3])
        mslep(process, text, passi)
    except ValueError:
        print(txtc.FAIL+"INVALID INPUT")
    except IndexError:
        try:
            process = str(sys.argv[1])
            if process == "-h":
                hlp()
            elif process == "-v":
                print(ver.cver)
            else:
                print("")
        except IndexError:
            hlp()
"""
def l3decrypt(token: bytes, key: bytes) -> bytes:
    return Fernet(key).decrypt(token)
"""

    