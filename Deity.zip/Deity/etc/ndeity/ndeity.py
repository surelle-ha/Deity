#pylint:disable=W0401
from tkinter import *
import configparser
config = configparser.ConfigParser()
config.read('../../usr/config.ini')
mainname = config['main']['name']
user = config['su']['user']
passwd = config['su']['passwd']

def prints():
    print("Helo, World!")

root = Tk()
root.title(mainname)
root.resizable(False, False)
sidebar = Frame(root, width=200, bg='white', height=500, relief='sunken', borderwidth=2)
sidebar.pack(expand=False, fill='both', side='left', anchor='nw')
frame = Frame(root, width=500, height=500)
frame.pack()
# menubar ------>1
# file ---------->2
menubar = Menu(root, background='lightblue', foreground='black',
               activebackground='#004c99', activeforeground='white')  
deity = Menu(menubar, tearoff=0)  
deity.add_command(label="Account")  
deity.add_command(label="Open")  
deity.add_command(label="Save")  
deity.add_command(label="Save as...")  
deity.add_command(label="Close")  
deity.add_separator()  
deity.add_command(label="Exit", command=root.quit)  
menubar.add_cascade(label="Settings", menu=deity)
# file ---------->2q
root.config(menu=menubar)
# menubar ------>1
root.mainloop()
