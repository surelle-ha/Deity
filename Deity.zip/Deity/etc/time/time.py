import time
import sys
import tkinter as tk

class App():
    def __init__(self):
        self.root = tk.Tk("Time")
        self.label = tk.Label(text="")
        self.label.pack()
        self.update_clock()
        self.root.mainloop()

    def update_clock(self):
        now = time.strftime("%H:%M:%S")
        self.label.configure(text=now)
        self.root.after(1000, self.update_clock)

def timehelp():
    print("j")

if __name__ == "__main__":    
    
    try:
        process = str(sys.argv[1])
        if process == "-c":
            print(time.strftime("%H:%M:%S"))
        elif process == "-d":
            app=App()
        else:
            print("")
    except AttributeError:
        print("No Display Detected!")
    except IndexError:
        print("")

