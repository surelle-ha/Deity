from gtts import gTTS 
import os 
from os import system, sys
from termcolor import colored

class info():
    version = "1.2"

print("Welcome to TextToVoice v"+info.version)
while True:
    try:
        ttvs = input(colored('[Text-Voice]=} ', 'grey', 'on_green'))
        language = 'en'
        myobj = gTTS(text=ttvs, lang=language, slow=False) 
        myobj.save("sound.mp3") 
        os.system("play -q sound.mp3")
    except KeyboardInterrupt:
        print(colored('CLOSED', 'white', 'on_red')+"\n")
        exit()
    except AssertionError:
        print("Character Unsupported.")
