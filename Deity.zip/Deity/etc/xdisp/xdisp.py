from os import system, sys

def xdis(ip, port):
	system(f"export DISPLAY={ip}:{port} && xfce4-session")


if __name__ == "__main__":
	ip = sys.argv[1]
	port = sys.argv[2]
	xdis(ip, port)
