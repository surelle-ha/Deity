# installation: 
# 
from os import system

def termux():
    system("pkg install python")
    system("pkg install python2")
    system("pkg install clang")
    system("pkg install wget && wget https://raw.githubusercontent.com/MasterDevX/java/master/installjava && bash installjava")
    system("pkg install sox")
    system("pip3 install configparser")
    system("pip3 install termcolor")
    system("pip3 install fernet")
    system("")
    
termux()