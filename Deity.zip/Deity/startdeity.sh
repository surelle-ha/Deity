python3 deity.py
